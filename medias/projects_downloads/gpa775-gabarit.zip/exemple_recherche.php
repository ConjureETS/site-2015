<?php 
/*Initialisation du sytème*/
include('database_connection.php');

include('_partials/header.php');
?>
<!-- Formulaire de recherche de professeur -->
<h1>Recherche de professeur</h1>
<form id="insertion" action="exemple_recherche.php" method="post">	
	<div>
		<label for="nom">Nom : </label>
		<input name="nom" id="nom" type="text" size="30" maxlength="40"/>
	</div>
	<div>
		<label for="prenom">Prénom : </label>
		<input name="prenom" id="prenom" type="text" size="30" maxlength="30"/>
	</div>
	<div>
		<label for="departement">Département : </label>
		<select name="id_departement" id="departement">
			<?php 
			//Début du code php pour créer la liste des départements
			$sql = "SELECT DISTINCT nom, id FROM departement";
			$departements = $con->query($sql);
			check_mysql_error();
			while($dep = $departements->fetch_array()) {
				?>
				<option value="<?php echo($dep["id"]); ?>"><?php echo($dep["nom"]); ?></option>
				<?php
			}
			//Fin du code de création de liste
			?>
		</select>
	</div>
	<input type="submit" name="soumettre" value="Soumettre" />
</form>
<!-- Fin du formulaire de recherche -->

<?php
//Début du code php de recherche de professeur
if(isset($_POST['soumettre'])) {
	//Filtrage des caractères spéciaux à partir des valeurs du formulaire
	$nom = !empty($_POST["nom"]) ? check_strip("nom") : "";
	$prenom = !empty($_POST["prenom"]) ? check_strip("prenom") : "";
	$departement = check_numeric("id_departement");
	if($nom == null)
		$nom = "";
	if($prenom == null)
		$prenom = "";
	
	//On cherche les professeurs dans la base de données ayant les critères entrées dans les champs.
	//Le caractère % représente une "wildcard" (n'importe quel caractère(s) dans une requête SQL)
	$sql = "SELECT DISTINCT professeur.nom 'nom', professeur.prenom 'prenom', departement.nom 'departement'
			FROM professeur, departement 
			WHERE professeur.id_departement = departement.id
			AND professeur.nom LIKE '%$nom%' AND professeur.prenom LIKE '%$prenom%' AND departement.id = $departement";
	$professeurs = $con->query($sql);
	check_mysql_error();
	?>
	
	<!-- Affichage de la liste des résultats -->
	<h2>Résultats de la recherche</h2>
	<ul>
	<?php
	while($prof = $professeurs->fetch_array()) {
		?>
		<li>
			<?php echo($prof["prenom"]." ".$prof["nom"].".............".$prof["departement"]); ?>
		</li>
		<?php
	}
	?>
	</ul>
	<?php
}

include('_partials/footer.php');
?>

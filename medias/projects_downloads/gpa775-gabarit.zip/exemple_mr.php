<?php
include('_partial/header.php');
?>
    <h1>Modèle relationnel</h1>
	<div class="modele_relationnel">
        <p>Voici le modèle relationnel pour de la base "Ecole" (utilisée pour les exemples) :</p>
		<img src="assets/Ecole-MR.png" />
	</div>
<?php
include('_partial/footer.php');
?>

<?php 
/*Initialisation du sytème*/
include('database_connection.php');

include('_partials/header.php');
?>
<!-- Formulaire HTML d'insertion d'un professeur -->
<h1>Insertion d'un professeur</h1>
<form id="insertion" action="exemple_insertion.php" method="post">	
	<div>
		<label for="nom">Nom : </label>
		<input name="nom" id="nom" type="text" size="30" maxlength="40"/>
	</div>
	<div>
		<label for="prenom">Prénom : </label>
		<input name="prenom" id="prenom" type="text" size="30" maxlength="30"/>
	</div>
	<div>
		<label for="departement">Département : </label>
		<select name="id_departement" id="departement"> 
			<?php //Début du code php pour créer la liste des départements
			$sql = "SELECT DISTINCT nom, id FROM departement";
			$departements = $con->query($sql);
			check_mysql_error();
			while($dep = $departements->fetch_array()){
				?>
				<option value="<?php echo($dep["id"]); ?>"><?php echo($dep["nom"]); ?></option>
				<?php
			}
			?>
		</select>
	</div>
	<input type="submit" name="soumettre" value="Soumettre" />
</form>
<!-- Fin du formulaire d'insertion -->

<?php
//Début du code php d'insertion de professeur
//La variable $_POST contient les valeurs du formulaire
if(isset($_POST['soumettre']))	{ 
	if(!empty($_POST['nom']) && !empty($_POST['prenom']) && !empty($_POST["id_departement"])) {
		
		//Filtrage des caractères spéciaux à partir des valeurs du formulaire
		$nom = check_strip("nom");
		$prenom = check_strip("prenom");
		$departement = check_numeric("id_departement");

		//Requête d'insertion
		$sql = "INSERT INTO professeur (nom, prenom, id_departement) VALUES ('$nom', '$prenom', $departement)";
		$con->query($sql);
		check_mysql_error();
		
		//Obtention du nom du département
		$sql = "SELECT nom FROM departement WHERE id = $departement";
		$dep = $con->query($sql);
		check_mysql_error();
		$ligneTemp = $dep->fetch_array();
		$nom_dep = $ligneTemp["nom"];
		?>
		<!-- Affichage du nouveau professeur -->
		<h2>Nouveau professeur inséré </h2>
		<div class="nouvelle_insertion">
			<p>Nom : <?php echo($nom) ?> </p>
			<p>Prénom : <?php echo($prenom) ?></p>
			<p>Département : <?php echo($nom_dep) ?> </p>
		</div>
		<?php
	}
	else {
		echo("*Veuillez remplir tout les champs");
	}
}

//Début du code php d'affichage de la liste des professeurs
$sql = "SELECT DISTINCT professeur.nom 'nom', professeur.prenom 'prenom', departement.nom 'departement'
		FROM professeur, departement 
		WHERE professeur.id_departement = departement.id";
$professeurs = $con->query($sql);
check_mysql_error();
?>
<!-- Affichage de la liste des professeurs -->
<h2>Liste des professeurs</h2>
<ul>
<?php
while($prof = $professeurs->fetch_array()) {
	?>
	<li>
		<?php echo($prof["prenom"]." ".$prof["nom"].".............".$prof["departement"]); ?>
	</li>
	<?php
}
?>
</ul>

<?php 
    include('_partials/footer.php');
?>

-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 30 Juin 2009 à 09:31
-- Version du serveur: 5.1.30
-- Version de PHP: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `Ecole`
--

-- --------------------------------------------------------

--
-- Structure de la table `cours`
--

CREATE TABLE IF NOT EXISTS `cours` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(40) NOT NULL,
  `Id_Professeur` int(11) NOT NULL,
  `Id_Departement` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id_Professeur` (`Id_Professeur`),
  KEY `Id_Departement` (`Id_Departement`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `cours`
--

INSERT INTO `cours` (`Id`, `Nom`, `Id_Professeur`, `Id_Departement`) VALUES
(1, 'Circuits électriques avancés', 6, 1),
(2, 'Conception de machine', 4, 2),
(3, 'Structures de données', 3, 3),
(4, 'Chimie des solutions', 1, 4),
(5, 'Mathématique physique', 1, 2);

-- --------------------------------------------------------

--
-- Structure de la table `departement`
--

CREATE TABLE IF NOT EXISTS `departement` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(40) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `departement`
--

INSERT INTO `departement` (`Id`, `Nom`) VALUES
(1, 'Génie électrique'),
(2, 'Génie mécanique'),
(3, 'Génie informatique'),
(4, 'Génie chimique'),
(5, 'Pas de département assigné');

-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE IF NOT EXISTS `etudiant` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(40) NOT NULL,
  `Prenom` varchar(30) NOT NULL,
  `Naissance` date NOT NULL,
  `Id_Departement` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id_Departement` (`Id_Departement`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Contenu de la table `etudiant`
--

INSERT INTO `etudiant` (`Id`, `Nom`, `Prenom`, `Naissance`, `Id_Departement`) VALUES
(1, 'Levasseur', 'Jean', '1984-06-14', 1),
(2, 'Beaudoin', 'Roger', '1965-11-10', 2),
(3, 'Paul', 'Ignatieff', '1982-09-07', 2),
(4, 'Alexandre', 'Beaupré', '1973-01-12', 3),
(5, 'Charles', 'Thé', '1982-03-03', 4),
(6, 'Dominic', 'Barbu', '1977-11-15', 1),
(7, 'Éric', 'Thibeau', '1984-06-13', 1),
(8, 'Frédéric', 'Arsenault', '1985-03-20', 2),
(9, 'Laurent', 'Bilbon', '1986-01-01', 3),
(10, 'Khaled', 'Ibn Yasser', '1981-06-05', 4),
(11, 'Hu', 'Xiang', '1967-09-13', 1),
(12, 'Maureen', 'Highvy', '1980-02-12', 2),
(13, 'Nicolas', 'Racine', '1990-08-27', 1),
(14, 'Qiang', 'Truong', '1982-03-23', 2),
(15, 'Tim', 'Harrison', '1976-03-07', 3),
(16, 'Vickie', 'Desmarais', '1982-04-12', 4),
(17, 'Guillaume', 'Hercules', '1981-02-25', 3);

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

CREATE TABLE IF NOT EXISTS `inscription` (
  `Id_Cours` int(11) NOT NULL,
  `Id_Etudiant` int(11) NOT NULL,
  KEY `Id_Cours` (`Id_Cours`,`Id_Etudiant`),
  KEY `Id_Etudiant` (`Id_Etudiant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `inscription`
--

INSERT INTO `inscription` (`Id_Cours`, `Id_Etudiant`) VALUES
(1, 1),
(1, 5),
(1, 6),
(1, 7),
(1, 11),
(1, 13),
(2, 2),
(2, 3),
(2, 8),
(2, 10),
(2, 12),
(2, 14),
(3, 4),
(3, 9),
(3, 15),
(3, 16),
(3, 17),
(4, 1),
(4, 5),
(4, 10),
(4, 16),
(5, 4),
(5, 6),
(5, 12),
(5, 15);

-- --------------------------------------------------------

--
-- Structure de la table `professeur`
--

CREATE TABLE IF NOT EXISTS `professeur` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(40) NOT NULL,
  `Prenom` varchar(30) NOT NULL,
  `Id_Departement` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Id_Departement` (`Id_Departement`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT AUTO_INCREMENT=8 ;

--
-- Contenu de la table `professeur`
--

INSERT INTO `professeur` (`Id`, `Nom`, `Prenom`, `Id_Departement`) VALUES
(1, 'Béliveau', 'Jean', 4),
(2, 'Nguyen', 'Kim', 2),
(3, 'Taillon', 'Gilles', 3),
(4, 'Orwell', 'Georges', 2),
(5, 'Timberlake', 'Justin', 3),
(6, 'Baron', 'Yves', 1);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `cours`
--
ALTER TABLE `cours`
  ADD CONSTRAINT `Cours_ibfk_1` FOREIGN KEY (`Id_Professeur`) REFERENCES `professeur` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Cours_ibfk_2` FOREIGN KEY (`Id_Departement`) REFERENCES `departement` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `Etudiant_ibfk_1` FOREIGN KEY (`Id_Departement`) REFERENCES `departement` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `inscription`
--
ALTER TABLE `inscription`
  ADD CONSTRAINT `Inscription_ibfk_2` FOREIGN KEY (`Id_Etudiant`) REFERENCES `etudiant` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Inscription_ibfk_1` FOREIGN KEY (`Id_Cours`) REFERENCES `cours` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `professeur`
--
ALTER TABLE `professeur`
  ADD CONSTRAINT `Professeur_ibfk_1` FOREIGN KEY (`Id_Departement`) REFERENCES `departement` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

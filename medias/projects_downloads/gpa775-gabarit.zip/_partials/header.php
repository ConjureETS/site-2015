<html lang="fr">
<head>
  <meta http-equiv="Content-Type" content="text/html" />
  <meta charset="UTF-8">
  <title>GPA775 - Exemple</title>
  <link rel="stylesheet" type="text/css" href="assets/global.css" />

</head>
<body>



 
   <?php
    if($_SERVER['REQUEST_URI'] != '/') { 
        ?>
        <a href="/">Retour au menu</a>
        <?php
    }
   ?>
  </body>
</html>

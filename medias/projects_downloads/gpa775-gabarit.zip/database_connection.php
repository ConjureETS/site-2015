<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

//Création de la connection à la base de données
$con = mysqli_connect('localhost', 'root', '', 'Ecole');
$con->set_charset("utf8");

//Fonction d'échapement des caractères spéciaux d'une valeur du formulaire
function check_strip($name){
	global $con;
	if(isset($_POST[$name]))
		return $con->real_escape_string($_POST[$name]);
	return false;
}

//Fonction qui vérifie si la valeur du formulaire est numérique
function check_numeric($name){
	if(isset($_POST[$name]) && is_numeric($_POST[$name]))
			return $_POST[$name];
    return false;
}

//Vérification des erreur mysql
function check_mysql_error(){
	if(mysql_error()){
		$err =  mysql_error() . "<br />";
		echo("$err");
	}
}
?>


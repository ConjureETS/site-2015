<?php
include('_partials/header.php');
?>
    <h1>Exemples d'interfaces</h1>
	<h4>Directives :</h4>
	<ol class="directives">
		<li>Téléchargez le fichier "Ecole.sql" (clic de droit sur le "Script de création de la base Ecole", ci-bas)</li>
		<li>Importez la base "Ecole" avec l'interface phpMyAdmin de votre ordinateur et le script "Ecole.sql"</li>
		<li>Consultez les exemples d'insertion et de recherche</li>
		<li>Copiez et modifiez les exemples pour votre base de données; consultez le modèle relationnel (ci-bas) au besoin</li>
	</ol>
	<h4>Liens :</h4>
	<ul class="liens_exemples">
		<li><a href="assets/Ecole.sql">Script de création de la base "Ecole"</a>
		<li><a href="exemple_mr.php">Consulter le modèle relationnel des exemples</a></li>
		<li><a href="exemple_insertion.php">Aller à la page d'exemple d'insertion</a></li>
		<li><a href="exemple_recherche.php">Aller à la page d'exemple de recherche</a></li>
	</ul>
<?php
include('_partials/footer.php');
?>
